# Temrin Notlandırma – Android APK kaynak projesi

Bu proje, Temrin Notlandırma HTML uygulamasını Android WebView içinde çalıştırır.

## Mevcut kapsam
- Temrin Notlandırma v7 arayüzü ve mevcut sınıf/öğrenci/temrin/not verileri uygulama içine gömülüdür.
- WebView JavaScript ve DOM depolaması açıktır; uygulama internet olmadan açılabilir.
- Veriler cihazdaki uygulama depolamasında tutulur. Uygulama kaldırılırsa veya uygulama verileri temizlenirse kayıtlar silinebilir. Bulut yedekleme henüz eklenmemiştir.
- Google Play'e hazır bir yayın değildir; ilk aşama cihazda test edilecek APK'dır.

## Derleme
Android SDK ve JDK 17+ bulunan bir ortamda Gradle 8.9 ile:

```bash
gradle assembleDebug
```

APK çıktısı:
`app/build/outputs/apk/debug/app-debug.apk`

Debug APK yalnızca test/kurulum içindir; Play Store için özel imzalı release paketi ve ileride AAB hazırlanmalıdır.

## Paket bilgileri
- Application ID: `tr.edu.temrinnotlandirma`
- Version: `1.0` (versionCode 1)
- Şu anki compileSdk/targetSdk: 35 (Play yayını öncesinde güncel hedef API'ye yükseltilip test edilmelidir.)
