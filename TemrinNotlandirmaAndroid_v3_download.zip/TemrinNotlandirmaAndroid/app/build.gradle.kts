plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "tr.edu.temrinnotlandirma"
    compileSdk = 35

    defaultConfig {
        applicationId = "tr.edu.temrinnotlandirma"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
